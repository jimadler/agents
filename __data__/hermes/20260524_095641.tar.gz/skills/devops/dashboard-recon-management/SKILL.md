---
name: dashboard-recon-management
description: Use when building, maintaining, or troubleshooting local-first dashboards (HTML/JS) for reconnaissance or status tracking.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [web, dashboard, reconnaissance, status-tracking]
    related_skills: [hermes-lifecycle]
---

# Dashboard Recon Management

## Overview
Manage static, local-first HTML/JS dashboards used for real-time reconnaissance or status tracking. These dashboards are meant to be fast, reliable, and "manually-fed" by the agent rather than relying on complex, brittle dynamic scrapers.

## When to Use
- You are building a status board for tracking targets (properties, market data, project status).
- You need a persistent, reliable hub to display processed intelligence.
- The dashboard is failing or requires frequent path/data-fetching updates.

## Core Philosophy: Stable > Dynamic
- **Static First**: Keep the "intelligence" data (the scores, status) in a hardcoded JS object or static file if possible.
- **Manual Feeding**: As the agent, update the static file directly when you gain new intel.
- **Client-Side Sync**: If using separate files (like `targets.txt`), ensure absolute consistency between the JS data object/fetcher and the source file.

- **Sidebar Best Practice**: Always include a "Home" link in the sidebar that points back to the main `index.html` hub (`<h2><a href="index.html">Hermes Hub</a></h2>`). This ensures users can always navigate out of sub-pages.
- **Always use relative paths** for navigation and data fetching (e.g., `vanguard-intel.html`, `targets.txt`) to ensure the dashboard works regardless of the server's root directory.
- **Use absolute paths starting with `/` only when standardizing site-wide navigation** that MUST land in the root, otherwise prefer relative paths for project sub-dashboards.
- **Plan Integrity**: When updating project roadmaps (PLAN.md), ALWAYS read the file first to understand its current length and structure. NEVER assume a file is empty or needs to be overwritten; if in doubt, read the file, append to it, or ask the user to verify the content before overwriting.
- **Path Integrity**: Always use site-root absolute paths (`/`) for navigation links and data fetching to prevent nested pathing errors, even if it feels correct to use relative paths. Relative paths are dangerous in multi-page, sub-directory-heavy structures.
- **File Integrity**: Before using `write_file` or `patch` on project configuration files or documentation (like `PLAN.md`), always verify the current file content to prevent unintentional data loss or overwriting of detailed history. Use `read_file` or `cat` first.

## Verification Checklist
- [ ] `targets.txt` structure matches the `Name|URL` format expected by JS.
- [ ] `index.html` script has the correct relative path to `targets.txt`.
- [ ] Sidebar navigation links point to the correct subdirectory/file structure.
- [ ] Dashboard is accessible via the current `ngrok` tunnel.

## Maintenance Workflow
1. If data is stale, update `index.html` or `targets.txt` directly.
2. If the "dashboard link" fails to load, check that navigation hrefs match the actual folder structure.
3. If new data points are needed, maintain consistency between JS and text files.
