---
name: hermes-backup
description: Backs up critical Hermes persistent data to a dated tar.gz archive.
---
# Skill: Hermes Backup

Trigger: Whenever I want to archive my agent's persistent data (memories, skills, config).

## Description
Creates a compressed `tar.gz` archive of *only* essential persistent data files and historical sessions from `~/.hermes/`. Included: `state.db`, `memories/`, `skills/`, `sessions/`, and `config.yaml`. Explicitly excludes all other files (logs, caches, framework code, `.env`, `node_modules`).

## Steps
1. Run the backup script: `~/.hermes/scripts/backup.sh`.
2. Locate the dated archive in `~/Projects/agents/__data__/hermes/`.

## Pitfalls
- This uses an explicit white-list approach. If you create new directories in `~/.hermes/` you want backed up, you must update `backup.sh`.
- The `.env` file is NOT backed up; keep a separate copy of your API keys if needed.
- `sessions/` can grow quite large over time; ensure your storage capacity can handle the growth.

## Verification
- Run `ls -lh ~/Backups/hermes/` to check that the archive was created successfully.
